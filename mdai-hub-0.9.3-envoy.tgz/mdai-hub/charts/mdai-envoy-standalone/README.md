# mdai-envoy-standalone

A Helm chart for running a standalone Envoy proxy with xDS bootstrap support.

## Prerequisites

- Kubernetes cluster
- Helm 3.x

## Install

From this chart directory:

```bash
helm install my-envoy . \
  --namespace default \
  --set xds.enabled=true \
  --set xds.serverAddress=<xds-hostname-or-ip> \
  --set xds.nodeId=<node-id> \
  --set xds.clusterName=<cluster-name>
```

## Optional Service Exposure

By default, the chart does **not** expose a Service port.
Set `service.port` to create the Kubernetes Service port and container port:

```bash
helm install my-envoy . \
  --set xds.enabled=true \
  --set xds.serverAddress=<xds-hostname-or-ip> \
  --set xds.nodeId=<node-id> \
  --set xds.clusterName=<cluster-name> \
  --set service.port=8126
```

Notes:
- `service.targetPort` defaults to `service.port` when omitted.
- `service.portName` defaults to `http` when omitted.

## Static Config Mode

If `xds.enabled=false`, you must provide `config` as a structured values object, for example in a values file:

```bash
helm install my-envoy . \
  --set xds.enabled=false \
  -f values-static.yaml
```

## Common Values

- `replicaCount`: Deployment replicas (default: `1`)
- `image.repository`: Envoy image repo (default: `envoyproxy/envoy`)
- `image.tag`: Envoy image tag (default: `v1.33.0`)
- `service.type`: Kubernetes Service type (default: `ClusterIP`)
- `service.port`: Optional Service/container port (no default)
- `xds.serverPort`: xDS gRPC server port (default: `18000`)
- `xds.adminAddress`: Envoy admin bind address (default: `0.0.0.0`)
- `xds.adminPort`: Envoy admin port (default: `19000`)
- `resources`: Container resource requests/limits (default: `{}`)
- `securityContext`: Container security context (default: `{}`)
- `podSecurityContext`: Pod security context (default: `{}`)

## Uninstall

```bash
helm uninstall my-envoy --namespace default
```
